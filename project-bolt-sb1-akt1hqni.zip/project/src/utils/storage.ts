// Storage utilities - currently unused but kept for future use
export const storage = {};